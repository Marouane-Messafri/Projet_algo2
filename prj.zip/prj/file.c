#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structures de données
typedef struct {
    int student_id;
    char name[50];
    int age;
    char major[50];
} Student;

typedef struct {
    int course_id;
    char course_name[50];
    char instructor[50];
} Course;

typedef struct {
    int student_id;
    int course_id;
} Enrollment;

// Fonctions d'analyse
void parse_students_csv(FILE *file, Student students[], int *num_students) {
    // Code pour lire et remplir l'arbre binaire de recherche des étudiants
    *num_students = 0;
    char line[256];

    while (fgets(line, sizeof(line), file) != NULL) {
        sscanf(line, "%d,%49[^,],%d,%49[^\n]", &students[*num_students].student_id,
               students[*num_students].name, &students[*num_students].age,
               students[*num_students].major);
        (*num_students)++;
    }
}

void parse_courses_csv(FILE *file, Course courses[], int *num_courses) {
    // Code pour lire et remplir l'arbre binaire de recherche des cours
    *num_courses = 0;
    char line[256];

    while (fgets(line, sizeof(line), file) != NULL) {
        sscanf(line, "%d,%49[^,],%49[^\n]", &courses[*num_courses].course_id,
               courses[*num_courses].course_name, courses[*num_courses].instructor);
        (*num_courses)++;
    }
}

void parse_follow_course_csv(FILE *file, Enrollment enrollments[], int *num_enrollments) {
    // Code pour lire et établir des liens entre les étudiants et les cours
    *num_enrollments = 0;
    char line[256];

    while (fgets(line, sizeof(line), file) != NULL) {
        sscanf(line, "%d,%d", &enrollments[*num_enrollments].student_id,
               &enrollments[*num_enrollments].course_id);
        (*num_enrollments)++;
    }
}

void serialize_students_csv(FILE *file, Student students[], int num_students) {
    // Code pour écrire les données des étudiants depuis l'arbre binaire de recherche des étudiants dans `students.csv`
    for (int i = 0; i < num_students; i++) {
        fprintf(file, "%d,%s,%d,%s\n", students[i].student_id, students[i].name,
                students[i].age, students[i].major);
    }
}

void serialize_courses_csv(FILE *file, Course courses[], int num_courses) {
    // Code pour écrire les données de cours depuis l'arbre binaire de recherche des cours dans `courses.csv`
    for (int i = 0; i < num_courses; i++) {
        fprintf(file, "%d,%s,%s\n", courses[i].course_id, courses[i].course_name,
                courses[i].instructor);
    }
}

void serialize_follow_course_csv(FILE *file, Enrollment enrollments[], int num_enrollments) {
    // Code pour écrire les données d'inscription depuis la base de données en mémoire dans `follow_course.csv`
    for (int i = 0; i < num_enrollments; i++) {
        fprintf(file, "%d,%d\n", enrollments[i].student_id, enrollments[i].course_id);
    }
}


/////////////////////////////////////////////////////////

// Déclaration des structures de données et des fonctions d'analyse/serialization ici...

// Fonction pour charger les données depuis les fichiers CSV dans la base de données en mémoire
void load_database(Student students[], int *num_students, Course courses[], int *num_courses, Enrollment enrollments[], int *num_enrollments) {
    FILE *students_file = fopen("students.csv", "r");
    FILE *courses_file = fopen("courses.csv", "r");
    FILE *enrollments_file = fopen("follow_course.csv", "r");

    if (students_file == NULL || courses_file == NULL || enrollments_file == NULL) {
        printf("Erreur lors de l'ouverture des fichiers CSV.\n");
        exit(EXIT_FAILURE);
    }

    // Charge les données depuis les fichiers CSV en utilisant les fonctions d'analyse
    parse_students_csv(students_file, students, num_students);
    parse_courses_csv(courses_file, courses, num_courses);
    parse_follow_course_csv(enrollments_file, enrollments, num_enrollments);

    // Ferme les fichiers après lecture
    fclose(students_file);
    fclose(courses_file);
    fclose(enrollments_file);

    printf("Données chargées avec succès!\n");
}

// Fonction pour enregistrer les modifications dans la base de données en mémoire dans les fichiers CSV
void save_database(Student students[], int num_students, Course courses[], int num_courses, Enrollment enrollments[], int num_enrollments) {
    FILE *students_file = fopen("students.csv", "w");
    FILE *courses_file = fopen("courses.csv", "w");
    FILE *enrollments_file = fopen("follow_course.csv", "w");

    if (students_file == NULL || courses_file == NULL || enrollments_file == NULL) {
        printf("Erreur lors de l'ouverture des fichiers CSV.\n");
        exit(EXIT_FAILURE);
    }

    // Écrit les modifications dans les fichiers CSV en utilisant les fonctions de sérialisation
    serialize_students_csv(students_file, students, num_students);
    serialize_courses_csv(courses_file, courses, num_courses);
    serialize_follow_course_csv(enrollments_file, enrollments, num_enrollments);

    // Ferme les fichiers après écriture
    fclose(students_file);
    fclose(courses_file);
    fclose(enrollments_file);

    printf("Modifications enregistrées avec succès!\n");
}

// Fonction pour détruire la base de données en mémoire et libérer les ressources de mémoire
void close_database(Student students[], Course courses[], Enrollment enrollments[]) {
    // Libère la mémoire occupée par les structures de données
    free(students);
    free(courses);
    free(enrollments);

    printf("Base de données fermée. Au revoir, vilain génie!\n");
}


////////////////////////////////////////////////



// Fonctions pour manipuler et interroger la base de données

// Fonction pour insérer un nouvel enregistrement d'étudiant
void insert_student(Student students[], int *num_students, char name[], int age, char major[]) {
    students[*num_students].student_id = *num_students + 1;
    strcpy(students[*num_students].name, name);
    students[*num_students].age = age;
    strcpy(students[*num_students].major, major);

    (*num_students)++;

    printf("Enregistrement d'étudiant inséré avec succès!\n");
}

// Fonction pour insérer un nouvel enregistrement de cours
void insert_course(Course courses[], int *num_courses, char course_name[], char instructor[]) {
    courses[*num_courses].course_id = *num_courses + 101; // Pour éviter les doublons avec les student_id
    strcpy(courses[*num_courses].course_name, course_name);
    strcpy(courses[*num_courses].instructor, instructor);

    (*num_courses)++;

    printf("Enregistrement de cours inséré avec succès!\n");
}

// Fonction pour récupérer et afficher les enregistrements d'étudiants en fonction des critères spécifiés
void select_students(Student students[], int num_students, char criteria[]) {
    // Code pour parcourir les étudiants et afficher ceux qui correspondent aux critères
    // ...
}

// Fonction pour récupérer et afficher les enregistrements de cours en fonction des critères spécifiés
void select_courses(Course courses[], int num_courses, char criteria[]) {
    // Code pour parcourir les cours et afficher ceux qui correspondent aux critères
    // ...
}

// Fonction pour supprimer les enregistrements d'étudiants en fonction des critères spécifiés
void delete_students(Student students[], int *num_students, char criteria[]) {
    // Code pour parcourir les étudiants et supprimer ceux qui correspondent aux critères
    // ...
}

// Fonction pour supprimer les enregistrements de cours en fonction des critères spécifiés
void delete_courses(Course courses[], int *num_courses, char criteria[]) {
    // Code pour parcourir les cours et supprimer ceux qui correspondent aux critères
    // ...
}

// Exemple d'utilisation dans le main












////////////////////////////////////////////////




int main() {
    // Déclaration des structures de données
    Student students[100];  // ajuste la taille en fonction de tes besoins
    Course courses[100];    // ajuste la taille en fonction de tes besoins
    Enrollment enrollments[100];  // ajuste la taille en fonction de tes besoins
    int num_students = 0, num_courses = 0, num_enrollments = 0;

    // Boucle principale du programme






    while (1) {
        char command[20];
        char entity[10];
        char criteria[50];

        printf("TntGpt> ");
        printf("entret la commande : INSERT , SELECT , DELETE\n ");
        scanf("%s", command);

        if (strcmp(command, "insert") == 0) {
            printf("student , course : \n ");
            scanf("%s", entity);
            if (strcmp(entity, "student") == 0) {
                char name[50];
                int age;
                char major[50];
                printf("student information : ");
                scanf("%s %d %s", name, &age, major);
                insert_student(students, &num_students, name, age, major);
            } else if (strcmp(entity, "course") == 0) {
                char course_name[50];
                char instructor[50];
                scanf("%s %s", course_name, instructor);
                insert_course(courses, &num_courses, course_name, instructor);
            }
        } else if (strcmp(command, "select") == 0) {
            scanf("%s %s", entity, criteria);
            if (strcmp(entity, "student") == 0) {
                select_students(students, num_students, criteria);
            } else if (strcmp(entity, "course") == 0) {
                select_courses(courses, num_courses, criteria);
            }
        } else if (strcmp(command, "delete") == 0) {
            scanf("%s %s", entity, criteria);
            if (strcmp(entity, "student") == 0) {
                delete_students(students, &num_students, criteria);
            } else if (strcmp(entity, "course") == 0) {
                delete_courses(courses, &num_courses, criteria);
            }
        } else if (strcmp(command, "load") == 0) {
            load_database(students, &num_students, courses, &num_courses, enrollments, &num_enrollments);
        } else if (strcmp(command, "save") == 0) {
            save_database(students, num_students, courses, num_courses, enrollments, num_enrollments);
        } else if (strcmp(command, "close") == 0) {
            close_database(students, courses, enrollments);
            break;
        } else {
            printf("Commande non reconnue. Essaye encore, petit diable!\n");
        }
    }






    return 0;
}














